import { Component, OnInit } from '@angular/core';
import { NewsService } from '../core/service/news.service';


@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.scss']
})
export class NewsComponent implements OnInit {

  imageSources: Array<any> = [];
  newsList: any;

  constructor(private news: NewsService) { }

  ngOnInit() {
    this.imageSources.push("https://cdn.vox-cdn.com/uploads/chorus_asset/file/9278671/jbareham_170917_2000_0124.jpg", "https://cdn.vox-cdn.com/uploads/chorus_image/image/56748793/dbohn_170625_1801_0018.0.0.jpg");
    this.trendingNewslist();
  }

  trendingNewslist() {
    this.news.getAllNewsList().subscribe((res) => {
      console.log(res);
      this.newsList = res['News'];
    });
  }

}
