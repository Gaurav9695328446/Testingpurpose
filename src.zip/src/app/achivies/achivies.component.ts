import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-achivies',
  templateUrl: './achivies.component.html',
  styleUrls: ['./achivies.component.scss']
})
export class AchiviesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
