import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-leader-profile-success',
  templateUrl: './my-leader-profile-success.component.html',
  styleUrls: ['./my-leader-profile-success.component.scss']
})
export class MyLeaderProfileSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
