export class LikeDislikeModel {
    profileId: string
    like: boolean
    dislike: boolean
}
export class RatingModel {
    overallRating: number
    personalImage: number
    PartyOrganisat: number
    qualification: number
    honesty: number
    accessibility: number
    workPerformance: number
    transparency: number
    activeness: number

}
export class AddRatingModel{
      profileId:String
	  rating:number
}
