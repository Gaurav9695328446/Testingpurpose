import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upcoming-elections',
  templateUrl: './upcoming-elections.component.html',
  styleUrls: ['./upcoming-elections.component.scss']
})
export class UpcomingElectionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
