export const environment = {
  production: true,
  API_URL: "http://139.162.53.4/netaji/"
};
