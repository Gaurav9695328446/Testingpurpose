// import { library } from '@fortawesome/fontawesome-svg-core';

// import { faCoffee } from '@fortawesome/free-solid-svg-icons';



// const icons = [
//     faCoffee
// ];

// library.add(...icons);